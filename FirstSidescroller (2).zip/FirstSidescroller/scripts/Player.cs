using Godot;
using System;

///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.

/// <summary>
/// Controls the player's movement and interactions in the game.
/// </summary>
public partial class Player : CharacterBody2D
{
	/// <summary>
	/// The player's movement speed.
	/// </summary>
	private const float SPEED = 110.0f;

	/// <summary>
	/// The velocity applied when the player jumps.
	/// </summary>
	private const float JUMP_VELOCITY = -300.0f;

	/// <summary>
	/// The gravity affecting the player.
	/// </summary>
	private float gravity = (float)ProjectSettings.GetSetting("physics/2d/default_gravity");

	/// <summary>
	/// The player's animated sprite, used for handling animations.
	/// </summary>
	private AnimatedSprite2D animatedSprite;

	/// <summary>
	/// Called when the node is added to the scene.
	/// Initializes the player and connects signals.
	/// </summary>
	public override void _Ready()
	{
		animatedSprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");

		// Locate the door node
		var door = GetNodeOrNull<Door>("../Door");
		if (door == null)
		{
			GD.PrintErr("Door node not found!");
			return;
		}

		// Check if the door node has the required signal
		if (!door.HasSignal(nameof(Door.PlayerEnteredEventHandler)))
		{
			GD.PrintErr($"Signal {nameof(Door.PlayerEnteredEventHandler)} does not exist on Door!");
			return;
		}

		// Connect the signal from the door node
		var connectionResult = door.Connect(nameof(Door.PlayerEnteredEventHandler), new Callable(this, nameof(OnDoorEntered)));
		if (connectionResult != Error.Ok)
		{
			GD.PrintErr($"Failed to connect signal: {connectionResult}");
		}
		else
		{
			GD.Print("Signal connected successfully!");
		}
	}

	/// <summary>
	/// Called every physics frame.
	/// Handles the player's movement and animation updates.
	/// </summary>
	/// <param name="delta">The frame delta time.</param>
	public override void _PhysicsProcess(double delta)
	{
		// Apply gravity if the player is not on the floor
		if (!IsOnFloor())
		{
			Velocity = new Vector2(Velocity.X, Velocity.Y + gravity * (float)delta);
		}

		// Handle jumping
		if (Input.IsActionJustPressed("jump") && IsOnFloor())
		{
			Velocity = new Vector2(Velocity.X, JUMP_VELOCITY);
		}

		// Handle horizontal movement
		float direction = Input.GetAxis("move_left", "move_right");

		if (direction > 0) animatedSprite.FlipH = false;
		else if (direction < 0) animatedSprite.FlipH = true;

		// Update animations
		if (IsOnFloor())
		{
			animatedSprite.Play(direction == 0 ? "Idle" : "Run");
		}
		else
		{
			animatedSprite.Play("Jump");
		}

		// Update velocity
		Velocity = direction != 0
			? new Vector2(direction * SPEED, Velocity.Y)
			: new Vector2(Mathf.MoveToward(Velocity.X, 0, 300.0f * (float)delta), Velocity.Y);

		// Stop minor movement
		if (Mathf.Abs(Velocity.X) < 1.0f)
		{
			Velocity = new Vector2(0, Velocity.Y);
		}

		// Apply movement
		MoveAndSlide();
	}

	/// <summary>
	/// Called when the player enters the door.
	/// </summary>
	private void OnDoorEntered()
	{
		GD.Print("Player received signal from Door!");
		// Add logic for handling door entry here
	}

	/// <summary>
	/// Respawns the player at the specified spawn position.
	/// </summary>
	/// <param name="spawnPosition">The position where the player will respawn.</param>
	public void Respawn(Vector2 spawnPosition)
	{
		Position = spawnPosition;
		Velocity = Vector2.Zero;
	}
}
