using Godot;
using System;

///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.

/// <summary>
/// Represents a collectible coin in the game.
/// </summary>
public partial class Coin : Area2D
{
	/// <summary>
	/// Called when the node is added to the scene and ready for interaction.
	/// Connects the "body_entered" signal to detect player interaction.
	/// </summary>
	public override void _Ready()
	{
		// Connect the signal using a Callable object
		GetNode<Area2D>("YourArea2DNode").Connect("body_entered", new Callable(this, nameof(OnBodyEntered)));
	}

	/// <summary>
	/// Handles the event when a body enters the coin's area.
	/// </summary>
	/// <param name="body">The node that entered the area.</param>
	private void OnBodyEntered(Node body)
	{
		GD.Print("+1 coin!");
	}
}
