using Godot;
using System;

///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.

/// <summary>
/// Represents the door that the player must reach to finish the level.
/// </summary>
public partial class Door : Area2D
{
	/// <summary>
	/// Signal emitted when the player enters the door's area.
	/// </summary>
	[Signal]
	public delegate void PlayerEnteredEventHandler();

	/// <summary>
	/// Called when the node is added to the scene and ready for interaction.
	/// Connects the "body_entered" signal to detect collisions with the player.
	/// </summary>
	public override void _Ready()
	{
		// Connect the BodyEntered signal to handle collisions with the player
		this.BodyEntered += OnPlayerEntered;
	}

	/// <summary>
	/// Handles the event when a body enters the door's area.
	/// </summary>
	/// <param name="body">The node that entered the area.</param>
	private void OnPlayerEntered(Node body)
	{
		// Check if the body is the player
		if (body is Player)
		{
			GD.Print("Player entered the door, emitting signal.");
			EmitSignal(nameof(PlayerEnteredEventHandler)); // Emit custom signal
		}
	}
}
