using Godot;
using System;

///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.

/// <summary>
/// Represents a killzone (e.g., water or lava) that resets the player's position.
/// </summary>
public partial class Killzone : Area2D
{
	/// <summary>
	/// The position where the player will respawn after touching the killzone.
	/// </summary>
	[Export]
	public Vector2 SpawnPosition { get; set; } = new Vector2(-62, 81);

	/// <summary>
	/// Called when the node is added to the scene and ready for interaction.
	/// Connects the "body_entered" signal to detect collisions with the player.
	/// </summary>
	public override void _Ready()
	{
		Connect("body_entered", new Callable(this, nameof(OnBodyEntered)));
	}

	/// <summary>
	/// Handles the event when a body enters the killzone's area.
	/// </summary>
	/// <param name="body">The node that entered the area.</param>
	private void OnBodyEntered(Node body)
	{
		if (body is Player player)
		{
			player.Respawn(SpawnPosition);
		}
	}
}
